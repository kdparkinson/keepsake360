var APP_DATA = {
  "name": "Untitled Project",
  "scenes": [
    {
      "id": "scene-1795228905624-0",
      "name": "FrontYard1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": -0.06985328812294433,
        "yaw": 1.2909283465320875,
        "fov": 1.20673440771442
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};