(function () {
  "use strict";

  var Marzipano = window.Marzipano;
  var APP_DATA = window.APP_DATA;

  if (!APP_DATA || !APP_DATA.scenes || !APP_DATA.scenes.length) {
    console.error("No APP_DATA or scenes found");
    return;
  }

  var panoElement = document.querySelector("#pano");
  var settings = APP_DATA.settings || {};

  if (settings.logoUrl && settings.showHeader !== false) {
    var logoImg = document.getElementById("brandLogo");
    if (logoImg) logoImg.style.display = "block";
  }

  var headerBar = document.getElementById("headerTitleBar");
  if (headerBar) {
    headerBar.style.display = (settings.showHeader !== false && settings.showSceneTitle !== false) ? "block" : "none";
  }

  var viewerOpts = {
    controls: {
      mouseViewMode: settings.mouseViewMode || "drag"
    }
  };

  var viewer = new Marzipano.Viewer(panoElement, viewerOpts);
  var activeSceneObj = null;
  var scenesById = {};

  var scenes = APP_DATA.scenes.map(function (data) {
    var urlPrefix = "tiles";
    var source = new Marzipano.ImageUrlSource(function (tile) {
      if (tile.z === 0) {
        return { url: urlPrefix + "/" + data.id + "/0/" + tile.face + "/0/0.jpg" };
      }
      return {
        url: urlPrefix + "/" + data.id + "/" + tile.z + "/" + tile.face + "/" + tile.y + "/" + tile.x + ".jpg"
      };
    });

    var limiter = Marzipano.RectilinearView.limit.traditional(
      data.faceSize || 4096,
      (100 * Math.PI) / 180
    );
    var view = new Marzipano.RectilinearView(data.initialViewParameters, limiter);
    var scene = viewer.createScene({
      source: source,
      geometry: new Marzipano.CubeGeometry(data.levels),
      view: view,
      pinFirstLevel: true
    });

    (data.linkHotspots || []).forEach(function (hotspot) {
      var element = createLinkHotspotElement(hotspot);
      scene.hotspotContainer().createHotspot(element, { yaw: hotspot.yaw, pitch: hotspot.pitch });
    });

    (data.infoHotspots || []).forEach(function (hotspot) {
      var element = createInfoHotspotElement(hotspot);
      scene.hotspotContainer().createHotspot(element, { yaw: hotspot.yaw, pitch: hotspot.pitch });
    });

    var sceneObj = { data: data, scene: scene, view: view };
    scenesById[data.id] = sceneObj;
    return sceneObj;
  });

  function createLinkHotspotElement(hotspot) {
    var wrapper = document.createElement("div");
    wrapper.className = "hotspot link-hotspot";
    var rotation = hotspot.rotation || 0;
    var totalRotation = -90 + (rotation * 180) / Math.PI;
    wrapper.innerHTML = '<div class="link-icon" style="transform: rotate(' + totalRotation + 'deg);">' +
      '<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M16 4 L28 16 L16 28 M28 16 L4 16" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>' +
      '</svg></div>';
    
    wrapper.addEventListener("click", function (e) {
      e.stopPropagation();
      var targetScene = findSceneById(hotspot.target);
      if (targetScene) {
        switchScene(targetScene, hotspot.targetView);
      }
    });
    return wrapper;
  }

  function createInfoHotspotElement(hotspot) {
    var wrapper = document.createElement("div");
    wrapper.className = "hotspot info-hotspot";
    var html = '<div class="info-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 12,22A10,10 0 0,0 12,22A10,10 0 0,0 12,2M11,17H13V11H11V17Z"/></svg></div>' +
      '<div class="info-text"><h3>' + (hotspot.title || "") + '</h3><p>' + (hotspot.text || "") + '</p>';
    if (hotspot.linkUrl) {
      html += '<a href="' + hotspot.linkUrl + '" target="_blank" class="info-hotspot-link" onclick="event.stopPropagation();">Buka Tautan ↗</a>';
    }
    html += '</div>';
    wrapper.innerHTML = html;

    wrapper.addEventListener("click", function (e) {
      e.stopPropagation();
      wrapper.classList.toggle("visible");
    });
    return wrapper;
  }

  function findSceneById(id) {
    return scenesById[id] || null;
  }

  var activeSceneObj = null;

  function switchScene(targetScene, overrideInitialView) {
    if (settings.autorotateEnabled) {
      viewer.stopMovement();
    }
    targetScene.view.setParameters(targetScene.data.initialViewParameters);
    targetScene.scene.switchTo();
    if (overrideInitialView) {
      targetScene.view.setParameters(overrideInitialView);
    }
    activeSceneObj = targetScene;
    
    var isTitleEnabled = settings.showSceneTitle !== false;
    var titlePos = settings.themeTitlePos || "navbar";
    var isNavbarEnabled = settings.showHeader !== false;

    var navTitleEl = document.getElementById("navbarSceneTitle");
    var floatTitleEl = document.getElementById("floatingSceneTitle");
    var navTitleSlot = document.getElementById("navbarTitleSlot");
    var floatTitleOverlay = document.getElementById("floatingTitleOverlay");

    if (navTitleSlot) navTitleSlot.style.display = "none";
    if (floatTitleOverlay) floatTitleOverlay.style.display = "none";

    if (isTitleEnabled) {
      var titleBgColor = settings.themeSceneTitleBgColor || "#000000";
      var titleBgOpacity = settings.themeSceneTitleBgOpacity !== undefined ? settings.themeSceneTitleBgOpacity : 80;
      var titleBgRgba = hexToRgba(titleBgColor, titleBgOpacity);

      if (titlePos === "navbar" && isNavbarEnabled && navTitleSlot && navTitleEl) {
        navTitleEl.textContent = targetScene.data.name;
        navTitleSlot.style.display = "flex";
        navTitleEl.style.backgroundColor = titleBgRgba;
        if (settings.themeSceneTitleFontColor) navTitleEl.style.color = settings.themeSceneTitleFontColor;
        if (settings.themeSceneTitleFontSize !== undefined) navTitleEl.style.fontSize = settings.themeSceneTitleFontSize + "px";
        if (settings.themeBorderRadius !== undefined) navTitleEl.style.borderRadius = settings.themeBorderRadius + "px";
      } else if (floatTitleOverlay && floatTitleEl) {
        floatTitleEl.textContent = targetScene.data.name;
        floatTitleOverlay.style.display = "block";
        floatTitleEl.style.backgroundColor = titleBgRgba;
        if (settings.themeSceneTitleFontColor) floatTitleEl.style.color = settings.themeSceneTitleFontColor;
        if (settings.themeSceneTitleFontSize !== undefined) floatTitleEl.style.fontSize = settings.themeSceneTitleFontSize + "px";
        if (settings.themeBorderRadius !== undefined) floatTitleEl.style.borderRadius = settings.themeBorderRadius + "px";

        var pos = titlePos.indexOf("overlay-") === 0 ? titlePos.replace("overlay-", "") : titlePos;
        floatTitleOverlay.style.top = pos.indexOf("top") !== -1 ? (isNavbarEnabled ? "64px" : "16px") : "auto";
        floatTitleOverlay.style.bottom = pos.indexOf("bottom") !== -1 ? "20px" : "auto";
        floatTitleOverlay.style.left = pos.indexOf("left") !== -1 ? "20px" : (pos.indexOf("center") !== -1 ? "50%" : "auto");
        floatTitleOverlay.style.right = pos.indexOf("right") !== -1 ? "20px" : "auto";
        floatTitleOverlay.style.transform = pos.indexOf("center") !== -1 ? "translateX(-50%)" : "none";
      }
    }

    updateSceneListActiveUI(targetScene);
  }

  function updateSceneListActiveUI(targetScene) {
    var items = document.querySelectorAll("#sceneListUl li");
    items.forEach(function(li) {
      if (li.getAttribute("data-id") === targetScene.data.id) {
        li.classList.add("active");
        var activeBg = settings.themeActiveItemBg || "#2ba9df";
        var activeOpacity = settings.themeActiveItemBgOpacity !== undefined ? settings.themeActiveItemBgOpacity : 100;
        li.style.backgroundColor = hexToRgba(activeBg, activeOpacity);
        if (settings.themeActiveItemFontColor) li.style.color = settings.themeActiveItemFontColor;
        if (settings.themeActiveItemFontSize !== undefined) li.style.fontSize = settings.themeActiveItemFontSize + "px";
        if (settings.themeActiveItemBorderRadius !== undefined) li.style.borderRadius = settings.themeActiveItemBorderRadius + "px";
        if (settings.themeActiveItemPadding !== undefined) li.style.padding = settings.themeActiveItemPadding + "px 12px";
      } else {
        li.classList.remove("active");
        li.style.backgroundColor = "";
        li.style.color = "";
        li.style.fontSize = "";
        li.style.borderRadius = "";
        li.style.padding = "";
      }
    });
  }

  var sceneListEl = document.querySelector("#sceneListUl");
  if (sceneListEl) {
    scenes.forEach(function (s) {
      if (s.data.showInSceneList !== false) {
        var li = document.createElement("li");
        li.textContent = s.data.name;
        li.setAttribute("data-id", s.data.id);
        li.addEventListener("click", function (e) {
          e.stopPropagation();
          switchScene(s);
        });
        sceneListEl.appendChild(li);
      }
    });
  }

  var toggleSceneListBtn = document.getElementById("toggleSceneListBtn");
  var sceneListContainer = document.getElementById("sceneListContainer");
  if (toggleSceneListBtn && sceneListContainer) {
    toggleSceneListBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      sceneListContainer.classList.toggle("collapsed");
    });
  }

  var btnFullscreen = document.getElementById("btnFullscreen");
  if (btnFullscreen) {
    btnFullscreen.addEventListener("click", function (e) {
      e.stopPropagation();
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(function(){});
      } else {
        document.exitFullscreen().catch(function(){});
      }
    });
  }

  if (settings.autorotateEnabled) {
    var autorotate = Marzipano.autorotate({ yawSpeed: 0.03 });
    viewer.startMovement(autorotate);
    viewer.setIdleMovement(3000, autorotate);
  }

  setupExportViewControls();

  function setupExportViewControls() {
    var movementInterval = null;
    function stepMove(action) {
      if (!activeSceneObj || !activeSceneObj.view) return;
      var view = activeSceneObj.view;
      var yaw = view.yaw();
      var pitch = view.pitch();
      var fov = view.fov();

      switch (action) {
        case "up": view.setPitch(pitch + 0.05); break;
        case "down": view.setPitch(pitch - 0.05); break;
        case "left": view.setYaw(yaw - 0.06); break;
        case "right": view.setYaw(yaw + 0.06); break;
        case "zoomIn": view.setFov(fov * 0.85); break;
        case "zoomOut": view.setFov(fov * 1.18); break;
      }
    }

    function startMove(action) {
      stopMove();
      stepMove(action);
      movementInterval = setInterval(function() { stepMove(action); }, 50);
    }

    function stopMove() {
      if (movementInterval) { clearInterval(movementInterval); movementInterval = null; }
    }

    var btnMap = [
      { id: "btnUp", action: "up" },
      { id: "btnDown", action: "down" },
      { id: "btnLeft", action: "left" },
      { id: "btnRight", action: "right" },
      { id: "btnZoomIn", action: "zoomIn" },
      { id: "btnZoomOut", action: "zoomOut" }
    ];

    btnMap.forEach(function(item) {
      var btn = document.getElementById(item.id);
      if (!btn) return;
      btn.addEventListener("mousedown", function(e) { e.preventDefault(); startMove(item.action); });
      btn.addEventListener("mouseup", function(e) { e.preventDefault(); stopMove(); });
      btn.addEventListener("mouseleave", function(e) { e.preventDefault(); stopMove(); });
      btn.addEventListener("touchstart", function(e) { e.preventDefault(); startMove(item.action); });
      btn.addEventListener("touchend", function(e) { e.preventDefault(); stopMove(); });
      btn.addEventListener("click", function(e) { e.preventDefault(); stepMove(item.action); });
    });
  }

  function hexToRgba(hex, opacityPercent) {
    if (!hex) return "rgba(0,0,0,0.85)";
    var c = hex.replace("#", "");
    if (c.length === 3) c = c.split("").map(function(x) { return x + x; }).join("");
    var r = parseInt(c.substring(0, 2), 16) || 0;
    var g = parseInt(c.substring(2, 4), 16) || 0;
    var b = parseInt(c.substring(4, 6), 16) || 0;
    var a = (opacityPercent !== undefined && opacityPercent !== null && !isNaN(opacityPercent)) ? opacityPercent / 100 : 0.85;
    return "rgba(" + r + "," + g + "," + b + "," + a + ")";
  }

  var panelBgRgba = hexToRgba(settings.themeBgColor || "#000000", settings.themeBgOpacity !== undefined ? settings.themeBgOpacity : 85);

  var isNavbarEnabled = settings.showHeader !== false;
  var topNavbar = document.getElementById("topNavbar");
  if (topNavbar) {
    topNavbar.style.display = isNavbarEnabled ? "flex" : "none";
    var navBgColor = settings.themeNavbarBgColor || settings.themeBgColor || "#000000";
    var navBgOpacity = settings.themeNavbarBgOpacity !== undefined ? settings.themeNavbarBgOpacity : 85;
    topNavbar.style.backgroundColor = hexToRgba(navBgColor, navBgOpacity);
    if (settings.themeFontColor) topNavbar.style.color = settings.themeFontColor;
  }

  var btnFullscreen = document.getElementById("btnFullscreen");
  var fullscreenOverlay = document.getElementById("fullscreenOverlay");
  var navbarFullscreenSlot = document.getElementById("navbarFullscreenSlot");
  var fsPos = settings.themeFullscreenPos || "navbar";
  var isFsEnabled = !!settings.fullscreenButton;

  if (fullscreenOverlay) fullscreenOverlay.style.display = "none";
  if (isFsEnabled && btnFullscreen) {
    if (settings.themeBorderRadius !== undefined) btnFullscreen.style.borderRadius = settings.themeBorderRadius + "px";
    btnFullscreen.style.backgroundColor = panelBgRgba;

    if (fsPos === "navbar" && isNavbarEnabled && navbarFullscreenSlot) {
      btnFullscreen.style.backgroundColor = "transparent";
      navbarFullscreenSlot.appendChild(btnFullscreen);
    } else if (fullscreenOverlay) {
      fullscreenOverlay.appendChild(btnFullscreen);
      fullscreenOverlay.style.display = "flex";
      var fPos = fsPos.indexOf("overlay-") === 0 ? fsPos.replace("overlay-", "") : fsPos;
      fullscreenOverlay.style.top = (fPos.indexOf("top") !== -1 || fPos.indexOf("below-header") !== -1) ? (isNavbarEnabled ? "64px" : "16px") : "auto";
      fullscreenOverlay.style.bottom = fPos.indexOf("bottom") !== -1 ? "20px" : "auto";
      fullscreenOverlay.style.left = fPos.indexOf("left") !== -1 ? "20px" : "auto";
      fullscreenOverlay.style.right = (fPos.indexOf("right") !== -1 || fPos.indexOf("below-header") !== -1) ? "20px" : "auto";
    }
  }

  var logoPos = settings.themeLogoPos || "navbar";
  var brandLogoOverlay = document.getElementById("brandLogoOverlay");
  var navbarLogoSlot = document.getElementById("navbarLogoSlot");
  var brandLogoImg = document.getElementById("brandLogo");

  if (brandLogoImg) {
    brandLogoImg.style.maxHeight = "40px";
    brandLogoImg.style.maxWidth = "160px";
    brandLogoImg.style.objectFit = "contain";
    brandLogoImg.style.display = "block";

    if (logoPos === "navbar" && isNavbarEnabled && navbarLogoSlot) {
      navbarLogoSlot.appendChild(brandLogoImg);
    } else if (brandLogoOverlay) {
      brandLogoOverlay.appendChild(brandLogoImg);
      brandLogoOverlay.style.display = "block";
      var lPos = logoPos.indexOf("overlay-") === 0 ? logoPos.replace("overlay-", "") : logoPos;
      brandLogoOverlay.style.top = lPos.indexOf("top") !== -1 ? (isNavbarEnabled ? "64px" : "16px") : "auto";
      brandLogoOverlay.style.bottom = lPos.indexOf("bottom") !== -1 ? "20px" : "auto";
      brandLogoOverlay.style.left = lPos.indexOf("left") !== -1 ? "20px" : "auto";
      brandLogoOverlay.style.right = lPos.indexOf("right") !== -1 ? "20px" : "auto";
    }
  }

  var sceneListOverlay = document.getElementById("sceneListOverlay");
  if (sceneListOverlay) {
    sceneListOverlay.style.top = isNavbarEnabled ? "64px" : "16px";
  }

  var viewControlOverlay = document.getElementById("viewControlOverlay");
  if (viewControlOverlay) {
    viewControlOverlay.style.display = settings.viewControlButtons ? "flex" : "none";
    var pos = settings.themeControlPos || "bottom-right";
    viewControlOverlay.style.top = pos.indexOf("top") !== -1 ? (isNavbarEnabled ? "64px" : "20px") : "auto";
    viewControlOverlay.style.bottom = pos.indexOf("bottom") !== -1 ? "20px" : "auto";
    viewControlOverlay.style.left = pos.indexOf("left") !== -1 ? "20px" : "auto";
    viewControlOverlay.style.right = pos.indexOf("right") !== -1 ? "20px" : "auto";
    if (settings.themeBorderRadius !== undefined) viewControlOverlay.style.borderRadius = settings.themeBorderRadius + "px";
    if (settings.themePadding !== undefined) viewControlOverlay.style.padding = settings.themePadding + "px";
    viewControlOverlay.style.backgroundColor = panelBgRgba;
  }

  if (sceneListContainer) {
    if (settings.themeBorderRadius !== undefined) sceneListContainer.style.borderRadius = settings.themeBorderRadius + "px";
    if (settings.themePadding !== undefined) sceneListContainer.style.padding = settings.themePadding + "px";
    sceneListContainer.style.backgroundColor = panelBgRgba;
    if (settings.themeFontColor) sceneListContainer.style.color = settings.themeFontColor;
    if (settings.themeFontSize !== undefined) sceneListContainer.style.fontSize = settings.themeFontSize + "px";
  }

  if (scenes.length > 0) {
    switchScene(scenes[0]);
  }
})();